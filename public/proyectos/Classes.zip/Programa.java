import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {

//////Espresiones//////
boolean k0=  ( 90.3231168712534  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 64.04832286553781  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k0);

//////ifs//////
if( ( 59.40601194366663  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 39.39758753666383  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k1=  ( 61.276907578349956  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 72.92437971103425  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k1);


}else{
if( ( 15.512408989208268  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 56.003230577685216  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k2=   35.587675736085394  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k2);
}if( ( 75.06676841445581  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 81.2869379454171  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k3=  ( 88.2988125338051  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 3.0133998374199455  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k3);
}}


//////whiles//////
int i5 = 0;
while(i5<1 && ( ( 93.61905481216165  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 40.327436800485096  != (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 12.528432362298062  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 2.6115337323247303  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k6=  ( 81.23020413714994  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 31.639381798906467  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k6);


}else{
if( ( 38.22493830962602  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 48.567010718674986  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k7=  ( 29.619282912165584  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1)) ;
result_tmp_num.add(k7);
}if( ( 23.661148287229462  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 45.99567138334254  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k8=  ( 67.31091690468317  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 13.035717118019226  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k8);
}}


i5++;
}


//////fors//////


//////Espresiones//////
double k9=   8.065442560927442  - (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k9);
}
private void exe1() {

//////Espresiones//////
double k10=   37.12120927917997  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k10);

//////ifs//////
if( ( 76.39044769370922  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 69.04300571031362  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k11=  ( 13.907351173971591  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 1.9600051815060744  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k11);


}else{
if( ( 73.98283421673527  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 47.28743921165087  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k12=  ( 28.912236940152784  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k12);
}if( ( 38.87177735201962  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 54.16944019818214  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k13=  ( 1.2763706063422524  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 43.88756399431542  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k13);
}}


//////whiles//////
int i15 = 1;
while(i15>0 && ( ( 49.485968332296956  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 41.41231818379958  < (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 85.35998939224073  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 8.13340383390107  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k16=  ( 35.571981096214664  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 90.77202866268237  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k16);


}else{
if( ( 15.12549700803094  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 10.209442828911035  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k17=  ( 24.82954580358679  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 49.78258467521004  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k17);
}if( ( 71.454317739229  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 2.2651789818236847  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k18=   88.49901923739831  / (-Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k18);
}}


i15--;
}

//////fors//////


//////Espresiones//////
double k19=   47.44184089486667  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k19);
}
private void exe2() {

//////Espresiones//////
double k20=   91.21618801596942  + (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k20);

//////ifs//////
if( ( 23.989185365460806  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 69.4249022322193  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k21=  ( 17.60780450037037  + (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k21);


}else{
if( ( 14.439021248725894  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 5.79144207804523  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k22=  ( 24.410654698309806  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 7.488382979904365  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k22);
}if( ( 24.753649695755083  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 27.906340723094058  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k23=   3.7744030206901553  / (-Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k23);
}}


//////whiles//////
int i25 = 0;
while(i25<1 && ( ( 66.45257759703392  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 34.14289581657876  > (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

double k26=   12.658207599839594  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k26);

i25++;
}


//////fors//////


//////Espresiones//////
double k27=  ( 35.47954059619452  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k27);
}
public char[] get_result_bool(int ini, int fin ) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
	return result_tmp_bool.toString().substring(ini, fin%(result_tmp_bool.toString().length())).toCharArray();
	}
public char[] get_result_num(int ini, int fin) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
		return result_tmp_num.toString().substring(ini, fin%(result_tmp_bool.toString().length())).toCharArray();	}

}
