import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {

//////Espresiones//////
double k0=   22.386689684576375  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k0);

//////ifs//////
if( ( 76.76276565894514  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 72.11896710184025  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k1=  ( 21.26508521923619  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k1);

if( ( 3.0320934791536533  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 59.73196546414047  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k2=   30.999596479814606  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k2);

if( ( 81.08681742262378  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 70.30192177620003  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k3=  ( 4.289903339030325  / (-Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1)) ;
result_tmp_num.add(k3);

if( ( 3.8669277222758516  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 15.783602612177958  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k4=  ( 32.77891020251588  - (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k4);

if( ( 75.43708007305595  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 71.23656826650148  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k5=  ( 58.20769690949149  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 65.97461591237372  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k5);


}else{
if( ( 90.15096009204794  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 19.38929004319653  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k6=  ( 4.501171625723173  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 96.98727058755179  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k6);
}if( ( 42.24759942414553  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 26.15456885960547  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k7=  ( 45.145266747382884  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 99.40257915907834  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k7);
}}

}else{
if( ( 41.32079636542623  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 2.0525295329634012  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k8=  ( 41.322412104289455  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 64.81116212247633  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k8);
}if( ( 78.35219051331981  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 5.794977826355709  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k9=  ( 43.24487796154138  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 92.81083239900003  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k9);
}}

}else{
if( ( 78.52140601460127  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 58.065450418947506  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k10=   62.93072634917611  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k10);
}if( ( 56.55544833977762  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 13.220300315771535  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k11=   37.73820297245258  + (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k11);
}}

}else{
if( ( 71.00833796174709  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 47.107767092031324  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k12=  ( 9.06452014066828  - (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k12);
}if( ( 24.36429245467212  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 25.838387995736003  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k13=   8.922388731930123  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k13);
}}

}else{
if( ( 18.636997122283905  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 33.16478640397579  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k14=  ( 68.60067892628079  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 98.72435607606948  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k14);
}if( ( 61.73645355726907  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 43.90965515529954  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k15=  ( 94.95304762461646  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 55.29671263740353  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k15);
}}


//////whiles//////
int i17 = 1;
while(i17>0 && ( ( 91.72866656411293  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 32.77385291338706  == (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

boolean k18=  ( 42.27305232461042  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 10.125975007821651  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k18);

i17--;
}

//////fors//////


//////Espresiones//////
double k19=   75.3063921912489  + (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k19);
}
public boolean[] get_result_bool(int ini, int fin ) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
	boolean[] a=new boolean[result_tmp_bool.size()];
		for (int i = ini; i < (fin<=result_tmp_bool.size()?fin : result_tmp_bool.size()); i++) {
			a[i]=result_tmp_bool.get(i);
		}
		return a;	}
public double[] get_result_num(int ini, int fin) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
		double[] a=new double[result_tmp_num.size()];
		for (int i = ini; i < (fin<=result_tmp_num.size()?fin : result_tmp_num.size()); i++) {
			a[i]=result_tmp_num.get(i);
		}
		return a;	}

}
