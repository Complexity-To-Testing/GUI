import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {
boolean k0=  ( 31.85548612616868  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 17.094142418951776  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 53.59065819540702  == (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k0);
boolean k1=  ( 13.845374897537328  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 2.0947223146681075  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 95.11631897804162  == (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k1);
if( ( 91.85944442439445  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 57.12466042777063  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 97.86225927638927  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
boolean k2=  ( 7.68382868584947  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 39.7697441609698  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 34.17743755695849  == (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k2);
double k3=  ( 18.309163391678663  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  - 76.55978983011087;
result_tmp_num.add(k3);

if( ( 38.976509796349575  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 32.50531357732644  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 29.74008836567138  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
double k4=  ( 65.35961526933153  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  / 90.28371489106894;
result_tmp_num.add(k4);
boolean k5=  ( 48.9906699657349  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 47.684352378716355  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 39.78058094348289  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k5);


}else{
if( ( 95.57145909811264  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 31.104232938796894  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 26.052678779656464  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
double k6=  ( 5.880009101865932  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  * 68.93338247371125;
result_tmp_num.add(k6);
boolean k7=  ( 27.44407202311644  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 83.04809518586362  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 6.430357445651301  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k7);

}if( ( 36.317137438164195  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 90.11570065803504  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 8.367001652957955  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
double k8=  ( 56.060810669141404  + (inputs_num[(inputs_num.length-1)%(p_num++)]) )  / 1.5994944489293186;
result_tmp_num.add(k8);
double k9=  ( 23.634103626227144  - (inputs_num[(inputs_num.length-1)%(p_num++)]) )  / 36.13228629472988;
result_tmp_num.add(k9);

}}

}else{
if( ( 73.42690883840878  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 88.90352676594941  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 96.41960717924341  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
double k10=   32.11587679559179  / (Math.abs((int)(inputs_num[(inputs_num.length-1)%(p_num++)]) )+1)  / 69.45364731655329;
result_tmp_num.add(k10);
boolean k11=  ( 95.15963199768301  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 67.31349689736876  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 17.611012532080412  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k11);

}if( ( 3.5591884773011353  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 17.650050458008685  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 94.22484973805689  == (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
boolean k12=  ( 88.89256915131696  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 54.65073655927645  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 48.45459698561606  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k12);
boolean k13=  ( 6.965167062395951  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 44.05953651900687  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 85.17651774149792  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k13);

}}

int i14 = 2;
while(i14>0 && ( ( 9.755163920980289  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 62.35507637389987  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 18.559479463646937  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) )){

boolean k15=  ( 56.30659019591595  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 25.352756949864308  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 34.88073549396308  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k15);
double k16=   96.85375728713439  - (inputs_num[(inputs_num.length-1)%(p_num++)])   - 40.06295454963976;
result_tmp_num.add(k16);
int i17 = 0;
while(i17<2 && ( ( 28.267415211566497  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 4.152611268428675  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 79.40888150385274  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) )){

boolean k18=  ( 69.60741089129115  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 15.457683058612217  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 1.6151616962519142  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k18);
double k19=  ( 46.94891614654017  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  + 35.070133598839725;
result_tmp_num.add(k19);
boolean k20=  ( 70.89801801337366  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 15.311116019077947  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 23.26493625979778  != (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k20);boolean k21=  ( 77.17447715547377  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 74.08704192412287  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 78.76402115637062  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k21);
boolean k22=  ( 99.62537190536072  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 92.75377734126118  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 36.16588505434539  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k22);

i17++;
}
boolean k23=  ( 76.26402997401443  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 6.555161451110276  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 39.15594912145799  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k23);
boolean k24=  ( 98.2976549040215  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 16.1799735675869  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 93.65116690205427  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k24);

i14--;
}
for(int i25=2;i25>0;i25 -- ){
double k26=   17.5486848499335  + (inputs_num[(inputs_num.length-1)%(p_num++)])   / 99.14743118878692;
result_tmp_num.add(k26);
boolean k27=  ( 97.5576207438357  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 98.73745067977107  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 64.53625387563312  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k27);

for(int i28=2;i28>0;i28 -- ){
double k29=   40.60193298962433  / (-Math.abs((int)(inputs_num[(inputs_num.length-1)%(p_num++)]) )+1)  - 78.69196324483238;
result_tmp_num.add(k29);
double k30=  ( 95.89262397376659  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  * 11.573622472848438;
result_tmp_num.add(k30);

boolean k31=  ( 42.7888500254399  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 9.46650069020647  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 79.15477098160066  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k31);double k32=  ( 71.04769503728645  + (inputs_num[(inputs_num.length-1)%(p_num++)]) )  - 4.623267295838811;
result_tmp_num.add(k32);
boolean k33=  ( 75.78766572864302  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 27.15202148186147  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 66.43799557138944  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k33);


}double k34=  ( 50.72024450745366  / (Math.abs((int)(inputs_num[(inputs_num.length-1)%(p_num++)]) )+1))  / 29.239430103536325;
result_tmp_num.add(k34);
boolean k35=  ( 37.37284271191625  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 9.712906402720158  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 46.57754100006435  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k35);


}
double k36=  ( 33.83794358191727  - (inputs_num[(inputs_num.length-1)%(p_num++)]) )  + 84.89035404895908;
result_tmp_num.add(k36);
double k37=  ( 3.712398919935175  * (inputs_num[(inputs_num.length-1)%(p_num++)]) )  + 44.07657225616457;
result_tmp_num.add(k37);
}
public boolean[] get_result_bool(int hasta_x) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_bool=new boolean[result_tmp_bool.size()];
		for(int i=0;i<(hasta_x<=result_tmp_num.size()?hasta_x : result_tmp_num.size());i++) {
			result_final_bool[i]=result_tmp_bool.get(i);
		}
		return result_final_bool;
	}
public double[] get_result_num(int hasta_x) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_num=new double[result_tmp_num.size()];
		for(int i=0;i<(hasta_x<=result_tmp_num.size()?hasta_x : result_tmp_num.size());i++) {
			result_final_num[i]=result_tmp_num.get(i);
		}
		return result_final_num;
	}

}
