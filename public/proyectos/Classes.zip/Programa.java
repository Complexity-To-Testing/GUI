import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {
boolean k0=  ( 63.552312970816274  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 17.241602338159304  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k0);
if( ( 56.386234866752766  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 43.568667251338155  != (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
boolean k1=  ( 22.93656833598684  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 52.734397630725105  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k1);


}else{
if( ( 9.841025212546626  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 97.55264219991776  != (inputs_num[(inputs_num.length-1)%(p_num++)])) ){
boolean k2=  ( 10.02903232469802  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 31.68694112747227  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k2);

}}

int i3 = 1;
while(i3>0 && ( ( 39.95570247672662  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 83.70425755267233  > (inputs_num[(inputs_num.length-1)%(p_num++)])) )){

double k4=  ( 22.821368241404837  + (inputs_num[(inputs_num.length-1)%(p_num++)]) ) ;
result_tmp_num.add(k4);
boolean k5=  ( 90.1662953743179  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 16.517805858459376  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k5);boolean k6=  ( 97.6950320837928  == (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 81.64421824435891  == (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k6);

i3--;
}
for(int i7=7;i7>0;i7 -- ){
boolean k8=  ( 35.29807274371749  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 20.1558202648788  >= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k8);

for(int i9=7;i9>0;i9 -- ){
boolean k10=  ( 9.55814175726168  <= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 40.84321195024998  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k10);

for(int i11=0;i11<7;i11 ++ ){
double k12=  ( 35.92332861636439  - (inputs_num[(inputs_num.length-1)%(p_num++)]) ) ;
result_tmp_num.add(k12);

for(int i13=2;i13<9;i13 ++ ){
boolean k14=  ( 14.845818266438823  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 38.11213567710496  <= (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k14);

for(int i15=6;i15<13;i15 ++ ){
double k16=   64.88909885659643  * (inputs_num[(inputs_num.length-1)%(p_num++)])  ;
result_tmp_num.add(k16);

for(int i17=0;i17<7;i17 ++ ){
boolean k18=  ( 49.673838637901994  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 89.80210960663553  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k18);

for(int i19=7;i19>0;i19 -- ){
boolean k20=  ( 42.80925218364441  != (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 26.236693896079796  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k20);

boolean k21=  ( 47.72447467143228  > (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 97.38628089212797  != (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k21);boolean k22=  ( 94.53747858483523  >= (inputs_num[(inputs_num.length-1)%(p_num++)]))  ||  ( 78.33376830444816  > (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k22);


}double k23=  ( 19.13714080302352  * (inputs_num[(inputs_num.length-1)%(p_num++)]) ) ;
result_tmp_num.add(k23);


}double k24=   39.70752001738494  / (-Math.abs((int)(inputs_num[(inputs_num.length-1)%(p_num++)]) )+1) ;
result_tmp_num.add(k24);


}double k25=   78.05971938699994  - (inputs_num[(inputs_num.length-1)%(p_num++)])  ;
result_tmp_num.add(k25);


}double k26=   56.485965470118714  - (inputs_num[(inputs_num.length-1)%(p_num++)])  ;
result_tmp_num.add(k26);


}boolean k27=  ( 74.82580081961628  < (inputs_num[(inputs_num.length-1)%(p_num++)]))  &&  ( 87.1562004636464  < (inputs_num[(inputs_num.length-1)%(p_num++)])) ;
result_tmp_bool.add(k27);


}double k28=   50.71532902771987  - (inputs_num[(inputs_num.length-1)%(p_num++)])  ;
result_tmp_num.add(k28);


}
double k29=   54.45467300530974  * (inputs_num[(inputs_num.length-1)%(p_num++)])  ;
result_tmp_num.add(k29);
}
public boolean[] get_result_bool(int ini, int fin) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_bool=new boolean[result_tmp_bool.size()];
		for(int i=ini;i<(fin < result_tmp_bool.size() ? fin : result_tmp_bool.size());i++) {
			result_final_bool[i]=result_tmp_bool.get(i);
		}
		return result_final_bool;
	}
public double[] get_result_num(int ini, int fin) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_num=new double[result_tmp_num.size()];
		for(int i=ini;i<(fin < result_tmp_num.size() ? fin : result_tmp_num.size());i++) {
			result_final_num[i]=result_tmp_num.get(i);
		}
		return result_final_num;
	}

}
