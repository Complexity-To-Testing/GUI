import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {

//////Espresiones//////
boolean k0=  ( 48.00356675047464  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 48.27496796032951  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k0);

//////ifs//////
if( ( 61.76711801340228  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 44.69256424875662  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k1=  ( 95.07396428334842  + (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k1);


}else{
if( ( 15.797075915365268  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 41.70398893816878  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k2=  ( 65.89834242757794  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k2);
}if( ( 30.020470618878832  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 61.47392961729158  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k3=  ( 75.88394071422339  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 8.96345721701863  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k3);
}}


//////whiles//////
int i5 = 0;
while(i5<1 && ( ( 9.82985472639204  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 70.66049672298215  < (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

double k6=  ( 52.903372868364485  + (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k6);

i5++;
}


//////fors//////


//////Espresiones//////
double k7=   84.77687167737716  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k7);
}
private void exe1() {

//////Espresiones//////
double k8=  ( 65.50326342803895  - (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k8);

//////ifs//////
if( ( 42.31858214061065  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 70.32742682471583  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k9=  ( 89.21766526787127  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 9.947788659040976  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k9);


}else{
if( ( 69.42197546487749  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 97.65594797498947  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k10=   72.00559101988034  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k10);
}if( ( 78.83701238792594  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 52.86389132756389  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k11=  ( 44.120482054105956  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 63.75580596053167  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k11);
}}


//////whiles//////
int i13 = 1;
while(i13>0 && ( ( 63.02763041334842  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 20.873142104835587  != (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 15.212238448707945  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 4.300072216524619  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k14=   83.53648165362675  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k14);


}else{
if( ( 60.935240497386474  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 20.31982659308811  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k15=  ( 46.98483155946952  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 53.944729792322214  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k15);
}if( ( 36.181011275037015  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 88.81585321114694  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k16=   15.922029054239356  + (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k16);
}}


i13--;
}

//////fors//////


//////Espresiones//////
boolean k17=  ( 25.392504728377595  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 57.648004713430204  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k17);
}
private void exe2() {

//////Espresiones//////
boolean k18=  ( 67.8369685879414  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 60.415435692929584  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k18);

//////ifs//////
if( ( 26.362466969228944  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 42.14517174071258  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k19=   81.85755480159959  + (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k19);


}else{
if( ( 21.78843908062822  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 97.5379148836207  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k20=  ( 71.59309161010779  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 75.06141588326268  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k20);
}if( ( 62.679292598619405  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 26.799536792728922  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k21=  ( 25.38803526072043  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 36.45058619329559  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k21);
}}


//////whiles//////
int i23 = 1;
while(i23>0 && ( ( 14.179703458744948  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 61.783522034991634  == (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 50.01107714101914  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 78.4147552784051  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k24=  ( 55.76132705294428  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 49.40308796851928  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k24);


}else{
if( ( 24.483169764160724  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 47.26187094032709  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k25=  ( 4.922400505104806  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 49.245065354022465  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k25);
}if( ( 13.57210835987321  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 29.089360763644162  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k26=  ( 54.28189303397353  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 11.58635982427003  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k26);
}}


i23--;
}

//////fors//////


//////Espresiones//////
double k27=   74.71091960208325  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k27);
}
public ArrayList<Boolean> get_result_bool(int ini, int fin ) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
	return result_tmp_bool.toString().substring(ini, fin%(result_tmp_bool.toString().length())).toCharArray();
	}
public ArrayList<Double> get_result_num(int ini, int fin) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
		return result_tmp_num.toString().substring(ini, fin%(result_tmp_bool.toString().length())).toCharArray();	}

}
