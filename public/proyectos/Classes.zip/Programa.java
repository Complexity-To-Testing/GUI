import java.util.ArrayList;

public class Programa{
	private int p_num=1;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	private int[]decisiones;///////nuevo atributo
	public Programa(double[] inputs_num,int[] decisiones) {
		this.inputs_num=inputs_num;
		this.decisiones=decisiones;
	}
private void exe0() {
boolean k0=  ( 45.93531125255029  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 72.5275940332117  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k0);
if( ( 50.04199659421673  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 47.871117706158316  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k1=  ( 84.9926598315521  + (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k1);


}else{
if( ( 6.2302976675645265  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 72.2478914699966  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k2=  ( 34.0360485744818  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 71.34760173701932  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k2);
}if( ( 14.814599963005687  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 61.76708752494111  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k3=  ( 56.28005865537532  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 53.273683998074645  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k3);
}}

int i5 = 0;
while(i5<1 && ( ( 14.431941890608986  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 15.474308398553914  != (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 27.173305222967464  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 14.293201069895014  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k6=  ( 75.5445132214098  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 20.78631384248184  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k6);


}else{
if( ( 11.97626245582133  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 33.09129924350245  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k7=  ( 17.616636179236117  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k7);
}if( ( 50.00574526382967  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 71.34607625159998  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k8=  ( 18.94043728541265  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 22.92461282962043  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k8);
}}


i5++;
}


double k9=  ( 69.77798050768276  * (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k9);
}
private void exe1() {
double k10=   34.921703191557995  / (-Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k10);
if( ( 78.08295108873561  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 27.02262741207338  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k11=  ( 1.7925987069687286  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 82.86325560928314  < (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k11);


}else{
if( ( 73.66895999899592  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 69.14903930514787  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k12=  ( 60.06783060389849  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 61.88158455741748  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k12);
}if( ( 66.278955410798  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 76.66971350260464  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k13=   44.25029450041055  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k13);
}}

int i15 = 0;
while(i15<1 && ( ( 33.86258250720871  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 43.62825341239505  < (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

if( ( 74.44131319693956  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 28.01448503894317  != (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k16=  ( 24.31790963741565  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 6.690224398059734  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k16);


}else{
if( ( 63.44346433821342  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 11.66555704930166  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k17=  ( 61.2530961638811  - (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k17);
}if( ( 27.584945460252555  <= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 54.24424092246643  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k18=   11.400483937348143  - (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k18);
}}


i15++;
}


double k19=  ( 34.015066648256926  - (inputs_num[(p_num++)%(inputs_num.length-1)]) ) ;
result_tmp_num.add(k19);
}
private void exe2() {
double k20=   86.73047604469397  * (inputs_num[(p_num++)%(inputs_num.length-1)])  ;
result_tmp_num.add(k20);
if( ( 35.539673351730265  > (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 90.12854244455326  <= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k21=  ( 79.85661456152306  != (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 16.961741586302082  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k21);


}else{
if( ( 98.57746408993852  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 24.38644320441995  >= (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
double k22=  ( 80.81263222800531  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1)) ;
result_tmp_num.add(k22);
}if( ( 19.145613794152055  >= (inputs_num[(p_num++)%(inputs_num.length-1)]))  ||  ( 39.911755173611475  == (inputs_num[(p_num++)%(inputs_num.length-1)])) ){
boolean k23=  ( 29.822681590619325  < (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 2.5171959106579944  > (inputs_num[(p_num++)%(inputs_num.length-1)])) ;
result_tmp_bool.add(k23);
}}

int i25 = 1;
while(i25>0 && ( ( 96.58935222912395  == (inputs_num[(p_num++)%(inputs_num.length-1)]))  &&  ( 58.24333281969658  != (inputs_num[(p_num++)%(inputs_num.length-1)])) )){

double k26=  ( 84.8685767946615  / (Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1)) ;
result_tmp_num.add(k26);

i25--;
}

double k27=   54.97119110404297  / (-Math.abs((int)(inputs_num[(p_num++)%(inputs_num.length-1)]) )+1) ;
result_tmp_num.add(k27);
}
public boolean[] get_result_bool(int ini, int hasta_x) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_bool=new boolean[result_tmp_bool.size()];
		for(int i=ini;i<(hasta_x<=result_tmp_bool.size()?hasta_x : result_tmp_bool.size());i++) {
			result_final_bool[i]=result_tmp_bool.get(i);
		}
		return result_final_bool;
	}
public double[] get_result_num(int ini,int hasta_x) {
		for(int i=0;i<decisiones.length;i++) {
			switch (decisiones[i]) {
			case 0:
				exe0();
				break;
case 1:
				exe1();
				break;
case 2:
				exe2();
				break;
default:
				exe0();
				break;
			}
		}
		
		result_final_num=new double[result_tmp_num.size()];
		for(int i=ini;i<(hasta_x<=result_tmp_num.size()?hasta_x : result_tmp_num.size());i++) {
			result_final_num[i]=result_tmp_num.get(i);
		}
		return result_final_num;
	}

}
