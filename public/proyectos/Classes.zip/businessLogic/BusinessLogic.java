package businessLogic;

public class BusinessLogic {
    public int getPrecio(int a, int b) {
        return  a+b;
    }
    public int getPrecio1(int a, int b) {
        return  a+b;
    }
}
