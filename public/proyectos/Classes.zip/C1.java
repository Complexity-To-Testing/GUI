import java.util.ArrayList;

public class C1{
	private int p_num=0;
	private ArrayList<Double> result_tmp_num=new ArrayList<Double>();
	private double[] result_final_num;
	private ArrayList<Boolean> result_tmp_bool=new ArrayList<Boolean>();
	private boolean[] result_final_bool;
	private double[] inputs_num;
	public C1(double[] inputs_num) {
		this.inputs_num=inputs_num;
	}
private void exe() {
boolean k0=  ( 87.95609818307946  > (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k0);
boolean k1=  ( 11.586776735605673  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 23.1697665947557  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 50.58754853408426  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 12.798646848550032  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k1);
if( ( 26.519837669768737  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ){
boolean k3=  ( 28.519922702753988  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k3);
boolean k2=  ( 28.79553102916997  <= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k2);
boolean k4=  ( 91.84283144008867  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 45.70524585467891  > (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 48.32608335553542  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 49.53985999909959  <= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k4);
}else {
double k5=   66.00018312771685  * (p_num<inputs_num.length ? inputs_num[p_num++] : 5)   +  ( 65.15660885561687  - (p_num<inputs_num.length ? inputs_num[p_num++] : 5) )  -   21.27953758786728  / (-Math.abs((int)(p_num<inputs_num.length ? inputs_num[p_num++] : 5) )+1)  / (-Math.abs((int)  74.7146065791547  + (p_num<inputs_num.length ? inputs_num[p_num++] : 5)  )+1);
result_tmp_num.add(k5);double k6=   55.60011474615965  - (p_num<inputs_num.length ? inputs_num[p_num++] : 5)   +   44.07259848454475  * (p_num<inputs_num.length ? inputs_num[p_num++] : 5)   *   82.25649790788765  * (p_num<inputs_num.length ? inputs_num[p_num++] : 5)   -  ( 96.66183491135007  - (p_num<inputs_num.length ? inputs_num[p_num++] : 5) ) ;
result_tmp_num.add(k6);boolean k7=  ( 42.203321003578985  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 91.22118526447413  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 44.72773215016237  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 88.1227410949975  <= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k7);
}
int i8 = 0;
while(i8<1 && ( ( 49.52199717498179  > (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 13.357272984201925  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 71.21067485121267  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) )){

boolean k9=  ( 54.21659069034363  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 32.861310363302806  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 44.77226226416896  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 63.8904134804682  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k9);boolean k10=  ( 90.12244959658254  <= (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 59.162529994783576  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 85.76670063719675  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 31.307562163189548  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k10);boolean k11=  ( 45.77862700461041  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k11);
i8++;
}

for(int i12=5;i12>0;i12 -- ){
double k13=  ( 14.862875109307739  / (Math.abs((int)(p_num<inputs_num.length ? inputs_num[p_num++] : 5) )+1))  *   56.46044124011273  * (p_num<inputs_num.length ? inputs_num[p_num++] : 5)   +   13.82134766943951  / (Math.abs((int)(p_num<inputs_num.length ? inputs_num[p_num++] : 5) )+1)  -  ( 59.59824786338041  / (Math.abs((int)(p_num<inputs_num.length ? inputs_num[p_num++] : 5) )+1)) ;
result_tmp_num.add(k13);
boolean k14=  ( 72.1062038175006  != (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 84.47302664349124  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 95.91196011307579  >= (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 90.47316479904798  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k14);boolean k15=  ( 64.95377172688404  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 95.31950054045022  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 43.92706898538591  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 39.575740608274565  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k15);

}
boolean k16=  ( 20.599736240221194  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 58.56283689422563  == (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  &&  ( 37.70995185439945  <= (p_num<inputs_num.length ? inputs_num[p_num++] : 5))  ||  ( 60.29932695550393  < (p_num<inputs_num.length ? inputs_num[p_num++] : 5)) ;
result_tmp_bool.add(k16);
double k17=   45.940267783929436  - (p_num<inputs_num.length ? inputs_num[p_num++] : 5)  ;
result_tmp_num.add(k17);
}
public boolean[] get_result_bool() {
		exe();
		result_final_bool=new boolean[result_tmp_bool.size()];
		for(int i=0;i<result_tmp_bool.size();i++) {
			result_final_bool[i]=result_tmp_bool.get(i);
		}
		return result_final_bool;
	}

	public double[] get_result_num() {
		exe();
		result_final_num=new double[result_tmp_num.size()];
		for(int i=0;i<result_tmp_num.size();i++) {
			result_final_num[i]=result_tmp_num.get(i);
		}
		return result_final_num;
	}
}
