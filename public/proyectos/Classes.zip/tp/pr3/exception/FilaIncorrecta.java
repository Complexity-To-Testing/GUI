package tp.pr3.exception;

public class FilaIncorrecta extends MovimientoInvalido{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public FilaIncorrecta (){super();}
	public FilaIncorrecta(String message){
		super(message);
	}
}
