package tp.pr3.exception;

@SuppressWarnings("serial")
public class ColumnaIncorrecta extends MovimientoInvalido{
	public ColumnaIncorrecta (){super();}
	public ColumnaIncorrecta(String message){
		super(message);
	}
}
