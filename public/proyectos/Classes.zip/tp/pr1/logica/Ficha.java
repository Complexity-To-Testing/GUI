package tp.pr1.logica; //Cristhian y Fabian

public enum Ficha {
	VACIA,BLANCA,NEGRA;
}
