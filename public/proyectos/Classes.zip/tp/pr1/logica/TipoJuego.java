package tp.pr1.logica;

public enum TipoJuego {
	C4, CO, GR
	
}
