package claseNodo;

public interface Figura {
	public double perimetro();
}
