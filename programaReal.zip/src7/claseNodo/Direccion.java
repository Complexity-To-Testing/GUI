package claseNodo;

public interface Direccion {
	public String getPos();
	public String getDir();

}
