package claseNodo.personaje;

import claseNodo.Coche;
import claseNodo.House;

public interface Propiedad {
	public String getHouse();
	public int getNumHouse();
	public String getCoche();
	public int getNumCoche();
	

}
