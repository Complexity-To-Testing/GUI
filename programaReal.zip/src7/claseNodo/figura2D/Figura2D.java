package claseNodo.figura2D;

import claseNodo.Figura;

public interface Figura2D extends Figura{
	public double getArea2D();
}
