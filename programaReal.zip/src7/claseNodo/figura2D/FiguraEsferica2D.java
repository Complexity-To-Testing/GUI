package claseNodo.figura2D;

public interface FiguraEsferica2D {
	public double getRadio();
	public double getArea();
}
