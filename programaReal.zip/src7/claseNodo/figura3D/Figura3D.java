package claseNodo.figura3D;

public interface Figura3D {
	public double getArea3D();
	public double getAltura();
	public double getVolumen();
	public String getFiguraBase();
}
